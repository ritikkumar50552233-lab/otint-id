// Usage: npm run hash-password -- "your-password"
import bcrypt from "bcryptjs";

const pw = process.argv[2];
if (!pw || pw.length < 10) {
  console.error('Usage: npm run hash-password -- "a-strong-password-of-10+-chars"');
  process.exit(1);
}
const hash = bcrypt.hashSync(pw, 12);
console.log("\nADMIN_PASSWORD_HASH (raw bcrypt):\n" + hash);
console.log(
  "\nADMIN_PASSWORD_HASH (base64, safe for .env files where '$' gets expanded):\n" +
    Buffer.from(hash).toString("base64") +
    "\n"
);
