import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0d17",
        panel: "#141829",
        line: "#262c4a",
        ink: "#e8eaf6",
        muted: "#8b92b8",
        brand: "#7c5cff",
        brand2: "#9d85ff",
        gold: "#fbbf24",
        ok: "#34d399",
        bad: "#f87171",
      },
      fontFamily: {
        sans: ["ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
