import { beforeAll, describe, expect, it } from "vitest";
import { NextRequest } from "next/server";
import { middleware } from "@/middleware";
import { SESSION_COOKIE, createSessionToken } from "@/lib/session";
import { TEST_ENV } from "./helpers";

beforeAll(TEST_ENV);

describe("admin middleware", () => {
  it("redirects unauthenticated admin pages to login and blocks admin APIs with 401", async () => {
    const page = await middleware(new NextRequest("http://x.test/admin"));
    expect(page.status).toBe(307);
    expect(page.headers.get("location")).toBe("http://x.test/admin/login");
    const api = await middleware(new NextRequest("http://x.test/api/admin/listings"));
    expect(api.status).toBe(401);
  });
  it("lets the login page and login API through, and lets a valid session in", async () => {
    expect((await middleware(new NextRequest("http://x.test/admin/login"))).headers.get("x-middleware-next")).toBe("1");
    expect((await middleware(new NextRequest("http://x.test/api/admin/login", { method: "POST" }))).headers.get("x-middleware-next")).toBe("1");
    const cookie = `${SESSION_COOKIE}=${await createSessionToken()}`;
    const ok = await middleware(new NextRequest("http://x.test/admin", { headers: { cookie } }));
    expect(ok.headers.get("x-middleware-next")).toBe("1");
  });
});
