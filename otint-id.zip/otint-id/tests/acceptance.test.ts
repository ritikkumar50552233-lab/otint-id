/**
 * Acceptance flow: SELL -> APPLY -> DATABASE -> ACTIVE -> BUY/LATEST -> DETAIL -> WHATSAPP -> ADMIN.
 * Uses a stateful in-memory stand-in for Prisma (honours `where`, `select`, `orderBy`), so the real route
 * handlers, serializers, query builders and page components run end to end. Only the database driver and
 * Vercel Blob are replaced; it does NOT test real PostgreSQL or real image storage.
 */
import { beforeAll, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { SESSION_COOKIE, createSessionToken } from "@/lib/session";
import { TEST_ENV, validForm } from "./helpers";

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any

const fake = vi.hoisted(() => {
  const rows: Row[] = [];
  let seq = 0;
  const pick = (r: Row, select?: Record<string, boolean>) =>
    select ? Object.fromEntries(Object.keys(select).filter((k) => select[k]).map((k) => [k, r[k]])) : { ...r };
  const cond = (r: Row, c: Row): boolean =>
    Object.entries(c).every(([k, v]) => String(r[k] ?? "").toLowerCase().includes(String((v as Row).contains).toLowerCase()));
  const matches = (r: Row, w: Row = {}): boolean => {
    if (w.status && r.status !== w.status) return false;
    if (typeof w.listingId === "string" && r.listingId !== w.listingId) return false;
    if (w.id && r.id !== w.id) return false;
    if (w.level?.gte != null && !(r.level != null && r.level >= w.level.gte)) return false;
    if (w.price?.gte != null && r.price < w.price.gte) return false;
    if (w.price?.lte != null && r.price > w.price.lte) return false;
    if (w.discount && "not" in w.discount && r.discount == null) return false;
    if (w.accountAge?.contains && !String(r.accountAge ?? "").toLowerCase().includes(w.accountAge.contains.toLowerCase())) return false;
    if (w.OR && !w.OR.some((c: Row) => cond(r, c))) return false;
    return true;
  };
  const listing = {
    create: async ({ data, select }: Row) => {
      const r = { id: `id${++seq}`, seq, status: "ACTIVE", createdAt: new Date(), updatedAt: new Date(), ...data };
      rows.push(r);
      return pick(r, select);
    },
    update: async ({ where, data, select }: Row) => {
      const r = rows.find((x) => matches(x, where));
      if (!r) throw new Error("not found");
      Object.assign(r, data, { updatedAt: new Date() });
      return pick(r, select);
    },
    findMany: async ({ where, select, orderBy, take }: Row = {}) => {
      const out = rows.filter((r) => matches(r, where));
      const o = orderBy?.[0] ?? orderBy ?? {};
      out.sort((a, b) => (o.price === "asc" ? a.price - b.price : o.price === "desc" ? b.price - a.price : b.seq - a.seq));
      return out.slice(0, take ?? 1000).map((r) => pick(r, select));
    },
    findFirst: async ({ where, select }: Row) => {
      const r = rows.find((x) => matches(x, where));
      return r ? pick(r, select) : null;
    },
    findUnique: async ({ where, select }: Row) => {
      const r = rows.find((x) => matches(x, where));
      return r ? pick(r, select) : null;
    },
  };
  return { rows, db: { listing, $transaction: async (fn: (tx: unknown) => unknown) => fn({ listing }) } };
});

vi.mock("@/lib/db", () => ({ prisma: fake.db }));
vi.mock("@/lib/storage", () => ({
  uploadImages: vi.fn(async (imgs: unknown[]) => imgs.map((_, i) => `https://blob.test/img${i}.png`)),
  deleteImages: vi.fn(),
}));
vi.mock("next/headers", () => ({
  headers: () => new Headers({ host: "shop.test", "x-forwarded-proto": "https" }),
  cookies: () => ({ get: () => undefined }),
}));

import { POST, GET as publicList } from "@/app/api/listings/route";
import { GET as publicDetail } from "@/app/api/listings/[listingId]/route";
import { GET as adminList } from "@/app/api/admin/listings/route";
import { PATCH, DELETE } from "@/app/api/admin/listings/[listingId]/route";
import Home from "@/app/page";
import BuyPage from "@/app/buy/page";
import ListingPage from "@/app/id/[listingId]/page";

const PHONE = "+919876543210";
const MGMT = "+91 77777 12345";

/* eslint-disable @typescript-eslint/no-explicit-any */
function walk(node: any, visit: (el: any) => void) {
  if (Array.isArray(node)) return node.forEach((n) => walk(n, visit));
  if (!node || typeof node !== "object" || !("props" in node)) return;
  visit(node);
  walk(node.props?.children, visit);
}
const cardIds = (tree: any) => {
  const ids: string[] = [];
  walk(tree, (el) => { if (el.props?.l?.listingId) ids.push(el.props.l.listingId); });
  return ids;
};
const hrefs = (tree: any) => {
  const out: string[] = [];
  walk(tree, (el) => { if (typeof el.props?.href === "string") out.push(el.props.href); });
  return out;
};
const dump = (tree: any) => JSON.stringify(tree, (k, v) => (k === "_owner" || k === "_store" ? undefined : v));
/* eslint-enable @typescript-eslint/no-explicit-any */

let n = 0;
const ip = () => ({ "x-forwarded-for": `172.16.0.${++n}` });
let listingId = "";

beforeAll(() => {
  TEST_ENV();
  process.env.MANAGEMENT_WHATSAPP_NUMBER = MGMT;
  process.env.NEXT_PUBLIC_SITE_URL = "";
});

describe("acceptance: SELL -> APPLY -> ACTIVE -> BUY/LATEST -> DETAIL -> WHATSAPP -> ADMIN", () => {
  it("1-3. saves a listing with 5 images, generates a unique id, status ACTIVE", async () => {
    const res = await POST(new NextRequest("http://shop.test/api/listings", { method: "POST", body: validForm(5), headers: ip() }));
    expect(res.status).toBe(201);
    listingId = (await res.json()).listingId;
    expect(listingId).toBe("OT-1001");
    const saved = fake.rows[0];
    expect(saved.status).toBe("ACTIVE");
    expect(saved.images).toHaveLength(5);
    expect(saved.sellerPhone).toBe(PHONE);

    const second = await POST(new NextRequest("http://shop.test/api/listings", { method: "POST", body: validForm(5), headers: ip() }));
    expect((await second.json()).listingId).toBe("OT-1002");
    fake.rows.pop(); // keep a single listing for the rest of the flow
  });

  it("4-5. appears immediately in BUY and in Latest/Recent (home)", async () => {
    expect(cardIds(await Home())).toContain(listingId);
    expect(cardIds(await BuyPage({ searchParams: {} }))).toContain(listingId);
  });

  it("buy filters work against stored data", async () => {
    expect(cardIds(await BuyPage({ searchParams: { minPrice: "2000", maxPrice: "3000" } }))).toContain(listingId);
    expect(cardIds(await BuyPage({ searchParams: { minPrice: "5000" } }))).not.toContain(listingId);
    expect(cardIds(await BuyPage({ searchParams: { discount: "1" } }))).not.toContain(listingId);
  });

  it("6-9. detail page works and the seller phone never appears publicly", async () => {
    const page = await ListingPage({ params: { listingId }, searchParams: {} });
    const html = dump(page);
    expect(html).toContain("123456789"); // UID
    expect(html).toContain("OT-1001");
    expect(html).not.toContain("9876543210");

    const apiList = await (await publicList(new NextRequest("http://shop.test/api/listings"))).text();
    const apiOne = await (await publicDetail(new Request("http://shop.test"), { params: { listingId } })).text();
    for (const body of [apiList, apiOne, dump(await Home()), dump(await BuyPage({ searchParams: {} }))]) {
      expect(body).not.toContain("9876543210");
      expect(body).not.toContain("sellerPhone");
    }
  });

  it("10-12. WhatsApp button uses the env number and includes exact listing id and URL", async () => {
    const page = await ListingPage({ params: { listingId }, searchParams: {} });
    const wa = hrefs(page).find((h) => h.startsWith("https://wa.me/"));
    expect(wa).toBeDefined();
    expect(wa!.startsWith("https://wa.me/917777712345?text=")).toBe(true);
    const text = decodeURIComponent(wa!.split("?text=")[1]);
    expect(text).toContain("Listing ID #OT-1001");
    expect(text).toContain("https://shop.test/id/OT-1001");
    expect(text).not.toContain("9876543210");
  });

  it("does not render a WhatsApp link when MANAGEMENT_WHATSAPP_NUMBER is not configured", async () => {
    const saved = process.env.MANAGEMENT_WHATSAPP_NUMBER;
    delete process.env.MANAGEMENT_WHATSAPP_NUMBER;
    const page = await ListingPage({ params: { listingId }, searchParams: {} });
    expect(hrefs(page).some((h) => h.startsWith("https://wa.me/"))).toBe(false);
    process.env.MANAGEMENT_WHATSAPP_NUMBER = saved;
  });

  it("13-21. admin sees the listing + phone, searches by id/uid/phone, SOLD hides it, restore shows it", async () => {
    const unauth = await adminList(new NextRequest("http://shop.test/api/admin/listings"));
    expect(unauth.status).toBe(401);

    const cookie = `${SESSION_COOKIE}=${await createSessionToken()}`;
    const search = async (q: string) =>
      (await (await adminList(new NextRequest(`http://shop.test/api/admin/listings?q=${encodeURIComponent(q)}`, { headers: { cookie } }))).json()).listings as Array<Record<string, string>>;

    const all = await search("");
    expect(all).toHaveLength(1);
    expect(all[0].sellerPhone).toBe(PHONE);
    expect((await search("OT-1001"))).toHaveLength(1);
    expect((await search("ot-1001"))).toHaveLength(1);
    expect((await search("123456789"))).toHaveLength(1);
    expect((await search("98765 43210"))).toHaveLength(1);
    expect((await search("+919876543210"))).toHaveLength(1);
    expect((await search("nomatch"))).toHaveLength(0);

    const patch = (action: string) =>
      PATCH(new Request("http://shop.test", { method: "PATCH", headers: { cookie }, body: JSON.stringify({ action }) }), { params: { listingId } });

    expect((await patch("sold")).status).toBe(200);
    expect(fake.rows[0].status).toBe("SOLD");
    expect(cardIds(await BuyPage({ searchParams: {} }))).not.toContain(listingId);
    expect(cardIds(await Home())).not.toContain(listingId);
    expect((await publicDetail(new Request("http://shop.test"), { params: { listingId } })).status).toBe(404);
    expect((await search("OT-1001"))).toHaveLength(1); // admin still sees it

    expect((await patch("restore")).status).toBe(200);
    expect(fake.rows[0].status).toBe("ACTIVE");
    expect(cardIds(await BuyPage({ searchParams: {} }))).toContain(listingId);

    // DELETE hides publicly (soft delete); restore brings it back
    const del = await DELETE(new Request("http://shop.test", { method: "DELETE", headers: { cookie } }), { params: { listingId } });
    expect(del.status).toBe(200);
    expect(fake.rows[0].status).toBe("DELETED");
    expect(cardIds(await BuyPage({ searchParams: {} }))).not.toContain(listingId);
    expect((await patch("restore")).status).toBe(200);
    expect(cardIds(await Home())).toContain(listingId);
  });

  it("admin edit validates per field and saves valid changes", async () => {
    const cookie = `${SESSION_COOKIE}=${await createSessionToken()}`;
    const edit = (fields: Record<string, string>) =>
      PATCH(new Request("http://shop.test", { method: "PATCH", headers: { cookie }, body: JSON.stringify({ action: "edit", fields }) }), { params: { listingId } });
    const ok = { sellerPhone: PHONE, uid: "123456789", price: "3100", discount: "5% off", level: "60", accountAge: "4 years", description: "Updated description text." };

    const bad = await edit({ ...ok, uid: "x" });
    expect(bad.status).toBe(422);
    expect((await bad.json()).fields.uid).toBeDefined();

    expect((await edit(ok)).status).toBe(200);
    expect(fake.rows[0].price).toBe(3100);
    expect(cardIds(await BuyPage({ searchParams: { discount: "1", minLevel: "50" } }))).toContain(listingId);
  });
});
