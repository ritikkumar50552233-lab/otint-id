import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { createSessionToken, SESSION_COOKIE } from "@/lib/session";
import { TEST_ENV, validForm } from "./helpers";

const db = vi.hoisted(() => ({
  listing: { findMany: vi.fn(), findFirst: vi.fn(), findUnique: vi.fn(), update: vi.fn(), create: vi.fn() },
  $transaction: vi.fn(),
}));
vi.mock("@/lib/db", () => ({ prisma: db }));
vi.mock("@/lib/storage", () => ({
  uploadImages: vi.fn(async (imgs: unknown[]) => imgs.map((_, i) => `https://blob.test/${i}.png`)),
  deleteImages: vi.fn(),
}));

import { POST, GET as listGet } from "@/app/api/listings/route";
import { GET as detailGet } from "@/app/api/listings/[listingId]/route";
import { GET as adminList } from "@/app/api/admin/listings/route";
import { PATCH, DELETE } from "@/app/api/admin/listings/[listingId]/route";

let n = 0;
const ip = () => ({ "x-forwarded-for": `10.0.0.${++n}` });
const PHONE = "+919876543210";
const row = {
  listingId: "OT-1001", uid: "123456789", price: 2500, discount: null, level: null, accountAge: null,
  description: "Clean account with rare items.", images: ["https://blob.test/0.png"], createdAt: new Date(),
  sellerPhone: PHONE, status: "ACTIVE", updatedAt: new Date(),
};

beforeEach(() => {
  TEST_ENV();
  vi.clearAllMocks();
});

describe("SELL -> APPLY -> ACTIVE", () => {
  it("creates an ACTIVE listing immediately with 5 images and a generated id", async () => {
    db.$transaction.mockImplementation(async (fn: (tx: unknown) => unknown) =>
      fn({
        listing: {
          create: vi.fn(async ({ data }: { data: Record<string, unknown> }) => {
            expect(data.status).toBe("ACTIVE");
            expect(data.sellerPhone).toBe(PHONE);
            expect((data.images as string[]).length).toBe(5);
            return { id: "x", seq: 1 };
          }),
          update: vi.fn(async ({ data }: { data: { listingId: string } }) => ({ listingId: data.listingId })),
        },
      })
    );
    const res = await POST(new NextRequest("http://localhost/api/listings", { method: "POST", body: validForm(5), headers: ip() }));
    expect(res.status).toBe(201);
    expect(await res.json()).toMatchObject({ listingId: "OT-1001", url: "/id/OT-1001" });
  });

  it("rejects fewer than 5 images and invalid fields on the server", async () => {
    const few = await POST(new NextRequest("http://localhost/api/listings", { method: "POST", body: validForm(3), headers: ip() }));
    expect(few.status).toBe(422);
    const f = validForm(5);
    f.set("uid", "x");
    const bad = await POST(new NextRequest("http://localhost/api/listings", { method: "POST", body: f, headers: ip() }));
    expect(bad.status).toBe(422);
    expect(db.$transaction).not.toHaveBeenCalled();
  });
});

describe("public API privacy and visibility", () => {
  it("never returns sellerPhone and only queries ACTIVE", async () => {
    db.listing.findMany.mockResolvedValue([row]);
    db.listing.findFirst.mockResolvedValue(row);
    const list = await listGet(new NextRequest("http://localhost/api/listings"));
    const text = await list.text();
    expect(text).not.toContain("9876543210");
    expect(text).not.toContain("sellerPhone");
    expect(db.listing.findMany.mock.calls[0][0].where.status).toBe("ACTIVE");
    expect(db.listing.findMany.mock.calls[0][0].select.sellerPhone).toBeUndefined();
    const one = await detailGet(new Request("http://localhost"), { params: { listingId: "OT-1001" } });
    expect(await one.text()).not.toContain("9876543210");
    expect(db.listing.findFirst.mock.calls[0][0].where).toMatchObject({ listingId: "OT-1001", status: "ACTIVE" });
  });
});

describe("admin authorization", () => {
  it("rejects unauthenticated admin API calls", async () => {
    expect((await adminList(new NextRequest("http://localhost/api/admin/listings"))).status).toBe(401);
    const ctx = { params: { listingId: "OT-1001" } };
    const r = (m: string) => new Request("http://localhost", { method: m, body: m === "PATCH" ? JSON.stringify({ action: "sold" }) : undefined });
    expect((await PATCH(r("PATCH"), ctx)).status).toBe(401);
    expect((await DELETE(r("DELETE"), ctx)).status).toBe(401);
    expect(db.listing.update).not.toHaveBeenCalled();
    expect(db.listing.findMany).not.toHaveBeenCalled();
  });

  it("rejects a forged cookie", async () => {
    const req = new NextRequest("http://localhost/api/admin/listings", { headers: { cookie: `${SESSION_COOKIE}=forged` } });
    expect((await adminList(req)).status).toBe(401);
  });

  it("lets an admin search (incl. phone), mark SOLD and restore", async () => {
    const cookie = `${SESSION_COOKIE}=${await createSessionToken()}`;
    db.listing.findMany.mockResolvedValue([row]);
    const res = await adminList(new NextRequest("http://localhost/api/admin/listings?q=9876543210", { headers: { cookie } }));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.listings[0].sellerPhone).toBe(PHONE);
    expect(JSON.stringify(db.listing.findMany.mock.calls[0][0].where)).toContain("sellerPhone");

    db.listing.findUnique.mockResolvedValue({ id: "x" });
    db.listing.update.mockImplementation(async ({ data }: { data: { status: string } }) => ({ ...row, status: data.status }));
    const ctx = { params: { listingId: "OT-1001" } };
    const mk = (action: string) => new Request("http://localhost", { method: "PATCH", headers: { cookie }, body: JSON.stringify({ action }) });
    const sold = await PATCH(mk("sold"), ctx);
    expect((await sold.json()).listing.status).toBe("SOLD");
    const back = await PATCH(mk("restore"), ctx);
    expect((await back.json()).listing.status).toBe("ACTIVE");
    const del = await DELETE(new Request("http://localhost", { method: "DELETE", headers: { cookie } }), ctx);
    expect((await del.json()).listing.status).toBe("DELETED");
  });
});
