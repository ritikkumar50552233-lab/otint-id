export const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
export const JPG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]);

export function pngFile(name = "a.png"): File {
  return new File([PNG], name, { type: "image/png" });
}

export function validForm(files = 5): FormData {
  const f = new FormData();
  f.set("sellerPhone", "+91 98765 43210");
  f.set("uid", "123456789");
  f.set("price", "2500");
  f.set("discount", "");
  f.set("level", "");
  f.set("accountAge", "");
  f.set("description", "Clean account with rare items.");
  for (let i = 0; i < files; i++) f.append("images", pngFile(`p${i}.png`));
  return f;
}

export const TEST_ENV = () => {
  process.env.SESSION_SECRET = "test-secret-test-secret-test-secret-1234";
};
