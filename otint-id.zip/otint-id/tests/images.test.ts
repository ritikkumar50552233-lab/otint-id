import { describe, expect, it } from "vitest";
import { detectImageType, validateImageFiles } from "@/lib/images";
import { JPG, PNG, pngFile } from "./helpers";

describe("image validation", () => {
  it("detects real types by magic bytes", () => {
    expect(detectImageType(PNG)).toBe("image/png");
    expect(detectImageType(JPG)).toBe("image/jpeg");
    const webp = Buffer.from("RIFF\0\0\0\0WEBP");
    expect(detectImageType(webp)).toBe("image/webp");
    expect(detectImageType(Buffer.from("GIF89a...."))).toBeNull();
  });
  it("requires at least 5 images", async () => {
    const r = await validateImageFiles([pngFile(), pngFile()]);
    expect(r.ok).toBe(false);
  });
  it("accepts 5 valid images", async () => {
    const r = await validateImageFiles(Array.from({ length: 5 }, () => pngFile()));
    expect(r.ok).toBe(true);
  });
  it("rejects a disguised file (wrong content, image mime type)", async () => {
    const fake = new File([Buffer.from("<?php echo 1; ?>")], "x.png", { type: "image/png" });
    const r = await validateImageFiles([fake, pngFile(), pngFile(), pngFile(), pngFile()]);
    expect(r.ok).toBe(false);
  });
});
