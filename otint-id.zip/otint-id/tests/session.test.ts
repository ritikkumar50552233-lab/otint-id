import { beforeEach, describe, expect, it } from "vitest";
import bcrypt from "bcryptjs";
import { createSessionToken, verifySessionToken, readCookie } from "@/lib/session";
import { verifyPassword } from "@/lib/auth";
import { TEST_ENV } from "./helpers";

beforeEach(TEST_ENV);

describe("admin session", () => {
  it("signs and verifies tokens; rejects garbage", async () => {
    const t = await createSessionToken();
    expect(await verifySessionToken(t)).toBe(true);
    expect(await verifySessionToken(t + "x")).toBe(false);
    expect(await verifySessionToken(null)).toBe(false);
  });
  it("parses cookies", () => {
    expect(readCookie("a=1; otint_admin=abc", "otint_admin")).toBe("abc");
  });
  it("verifies password against raw and base64 bcrypt hashes", async () => {
    const hash = bcrypt.hashSync("correct-horse-battery", 4);
    process.env.ADMIN_PASSWORD_HASH = hash;
    expect(await verifyPassword("correct-horse-battery")).toBe(true);
    expect(await verifyPassword("wrong")).toBe(false);
    process.env.ADMIN_PASSWORD_HASH = Buffer.from(hash).toString("base64");
    expect(await verifyPassword("correct-horse-battery")).toBe(true);
    delete process.env.ADMIN_PASSWORD_HASH;
    expect(await verifyPassword("correct-horse-battery")).toBe(false);
  });
});
