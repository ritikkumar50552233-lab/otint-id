import { describe, expect, it } from "vitest";
import { buildWhatsAppUrl } from "@/lib/whatsapp";

const p = { listingId: "OT-1001", uid: "123456789", price: 2500, url: "https://example.com/id/OT-1001" };

describe("whatsapp url", () => {
  it("uses the provided management number and encodes the message", () => {
    const url = buildWhatsAppUrl("+91 99999 00000", p)!;
    expect(url.startsWith("https://wa.me/919999900000?text=")).toBe(true);
    const text = decodeURIComponent(url.split("?text=")[1]);
    expect(text).toContain("Listing ID #OT-1001");
    expect(text).toContain("UID: 123456789");
    expect(text).toContain("https://example.com/id/OT-1001");
    expect(text).toContain("₹2,500");
    expect(url).not.toContain(" ");
  });
  it("returns null when the env number is missing", () => {
    expect(buildWhatsAppUrl(undefined, p)).toBeNull();
    expect(buildWhatsAppUrl("", p)).toBeNull();
  });
});
