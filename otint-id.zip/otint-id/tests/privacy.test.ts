import { describe, expect, it, vi } from "vitest";
vi.mock("@/lib/db", () => ({ prisma: {} }));

import { PUBLIC_SELECT, toAdminListing, toPublicListing } from "@/lib/serializers";
import { buildPublicWhere, buildAdminWhere, parseFilters } from "@/lib/listings";

const row = {
  listingId: "OT-1001", uid: "123456789", price: 2500, discount: null, level: 50, accountAge: "2y",
  description: "desc desc desc", images: ["https://x/1.jpg"], createdAt: new Date("2026-01-01"),
  sellerPhone: "+919876543210", status: "ACTIVE" as const, updatedAt: new Date("2026-01-02"),
};

describe("seller phone privacy", () => {
  it("public DTO never contains sellerPhone, even when given a full row", () => {
    const pub = toPublicListing(row);
    expect(JSON.stringify(pub)).not.toContain("9876543210");
    expect("sellerPhone" in pub).toBe(false);
    expect("status" in pub).toBe(false);
  });
  it("public select does not include sellerPhone", () => {
    expect(Object.keys(PUBLIC_SELECT)).not.toContain("sellerPhone");
  });
  it("admin DTO includes sellerPhone", () => {
    expect(toAdminListing(row).sellerPhone).toBe("+919876543210");
  });
});

describe("filtering", () => {
  it("public queries are always ACTIVE only (SOLD/DELETED hidden)", () => {
    expect(buildPublicWhere({}).status).toBe("ACTIVE");
    expect(buildPublicWhere({ minPrice: 1, discount: true, minLevel: 10, age: "2" }).status).toBe("ACTIVE");
  });
  it("parses filters safely", () => {
    const f = parseFilters({ minPrice: "100", maxPrice: "abc", sort: "price_asc", discount: "1" });
    expect(f.minPrice).toBe(100);
    expect(f.maxPrice).toBeUndefined();
    expect(f.sort).toBe("price_asc");
    expect(f.discount).toBe(true);
    expect(parseFilters({ sort: "evil" }).sort).toBe("newest");
  });
  it("admin search covers listing id, uid and phone", () => {
    const w = buildAdminWhere("OT-1001", "SOLD");
    expect(w.status).toBe("SOLD");
    expect(w.OR).toHaveLength(3);
  });
});
