import { describe, expect, it } from "vitest";
import { listingFieldsSchema } from "@/lib/validation";

const base = { sellerPhone: "+91 98765-43210", uid: "123456789", price: "2500", description: "A clean account with items." };

describe("listing validation", () => {
  it("accepts valid input and normalises phone", () => {
    const r = listingFieldsSchema.parse({ ...base, discount: "", level: "", accountAge: "" });
    expect(r.sellerPhone).toBe("+919876543210");
    expect(r.price).toBe(2500);
    expect(r.level).toBeUndefined();
    expect(r.discount).toBeUndefined();
  });
  it("accepts optional fields", () => {
    const r = listingFieldsSchema.parse({ ...base, level: "75", accountAge: "3 years", discount: "10% off" });
    expect(r.level).toBe(75);
    expect(r.accountAge).toBe("3 years");
  });
  it.each([
    ["bad phone", { sellerPhone: "12ab" }],
    ["bad uid", { uid: "12" }],
    ["zero price", { price: "0" }],
    ["text price", { price: "abc" }],
    ["short description", { description: "short" }],
    ["bad level", { level: "9999" }],
  ])("rejects %s", (_n, patch) => {
    expect(listingFieldsSchema.safeParse({ ...base, ...patch }).success).toBe(false);
  });
  it("strips angle brackets from text", () => {
    const r = listingFieldsSchema.parse({ ...base, description: "<script>alert(1)</script> nice account" });
    expect(r.description).not.toMatch(/[<>]/);
  });
});
