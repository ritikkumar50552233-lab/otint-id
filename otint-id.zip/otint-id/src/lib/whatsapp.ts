export function digitsOnly(s: string): string {
  return s.replace(/\D/g, "");
}

export function formatPrice(price: number): string {
  return `₹${price.toLocaleString("en-IN")}`;
}

export function buildInquiryMessage(p: { listingId: string; uid: string; price: number; url: string }): string {
  return [
    `Hello, I am interested in Listing ID #${p.listingId}.`,
    `UID: ${p.uid}`,
    `Price: ${formatPrice(p.price)}`,
    `Listing: ${p.url}`,
    `Please provide more information about this listing.`,
  ].join("\n");
}

/** Returns null when the management number is not configured. */
export function buildWhatsAppUrl(
  managementNumber: string | undefined,
  p: { listingId: string; uid: string; price: number; url: string }
): string | null {
  const num = digitsOnly(managementNumber ?? "");
  if (num.length < 8) return null;
  return `https://wa.me/${num}?text=${encodeURIComponent(buildInquiryMessage(p))}`;
}
