/**
 * Public/private DTOs. Public output is built by explicit field picking,
 * so sellerPhone can never leak even if a row containing it is passed in.
 */
export const PUBLIC_SELECT = {
  listingId: true,
  uid: true,
  price: true,
  discount: true,
  level: true,
  accountAge: true,
  description: true,
  images: true,
  createdAt: true,
} as const;

type PublicRow = {
  listingId: string;
  uid: string;
  price: number;
  discount: string | null;
  level: number | null;
  accountAge: string | null;
  description: string;
  images: string[];
  createdAt: Date;
};

export type PublicListing = Omit<PublicRow, "createdAt"> & { createdAt: string };

export function toPublicListing(row: PublicRow): PublicListing {
  return {
    listingId: row.listingId,
    uid: row.uid,
    price: row.price,
    discount: row.discount,
    level: row.level,
    accountAge: row.accountAge,
    description: row.description,
    images: [...row.images],
    createdAt: row.createdAt.toISOString(),
  };
}

type AdminRow = PublicRow & {
  sellerPhone: string;
  status: "ACTIVE" | "SOLD" | "DELETED";
  updatedAt: Date;
};

export type AdminListing = PublicListing & {
  sellerPhone: string;
  status: "ACTIVE" | "SOLD" | "DELETED";
  updatedAt: string;
};

export function toAdminListing(row: AdminRow): AdminListing {
  return {
    ...toPublicListing(row),
    sellerPhone: row.sellerPhone,
    status: row.status,
    updatedAt: row.updatedAt.toISOString(),
  };
}
