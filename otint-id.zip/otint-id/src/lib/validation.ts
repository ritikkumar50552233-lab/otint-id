import { z } from "zod";

/** Remove angle brackets and control characters. React escapes output too; this is defence in depth. */
export function sanitizeText(s: string): string {
  return s
    .replace(/[<>]/g, "")
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .trim();
}

export function normalizePhone(s: string): string {
  return s.replace(/[\s\-().]/g, "");
}

const emptyToUndefined = (v: unknown) => (typeof v === "string" && v.trim() === "" ? undefined : v);

const optionalText = (max: number) =>
  z.preprocess(
    emptyToUndefined,
    z
      .string()
      .max(max, `Must be ${max} characters or fewer`)
      .transform(sanitizeText)
      .optional()
  );

const optionalInt = (min: number, max: number, label: string) =>
  z.preprocess(
    emptyToUndefined,
    z.coerce
      .number({ invalid_type_error: `${label} must be a number` })
      .int(`${label} must be a whole number`)
      .min(min, `${label} must be at least ${min}`)
      .max(max, `${label} must be at most ${max}`)
      .optional()
  );

export const listingFieldsSchema = z.object({
  sellerPhone: z
    .string({ required_error: "Phone number is required" })
    .transform(normalizePhone)
    .pipe(z.string().regex(/^\+?\d{10,15}$/, "Enter a valid phone number (10-15 digits)")),
  uid: z
    .string({ required_error: "UID is required" })
    .trim()
    .regex(/^\d{6,15}$/, "UID must be 6-15 digits"),
  price: z.coerce
    .number({ invalid_type_error: "Price must be a number", required_error: "Price is required" })
    .int("Price must be a whole number")
    .min(1, "Price must be at least 1")
    .max(10_000_000, "Price is too high"),
  discount: optionalText(100),
  level: optionalInt(1, 200, "Level"),
  accountAge: optionalText(50),
  description: z
    .string({ required_error: "Description is required" })
    .max(1000, "Description must be 1000 characters or fewer")
    .transform(sanitizeText)
    .pipe(z.string().min(10, "Description must be at least 10 characters")),
});

export type ListingFields = z.infer<typeof listingFieldsSchema>;

export function fieldErrors(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[issue.path.length - 1] ?? "form");
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

export const adminActionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("sold") }),
  z.object({ action: z.literal("restore") }),
  z.object({ action: z.literal("edit"), fields: listingFieldsSchema }),
]);

export const loginSchema = z.object({ password: z.string().min(1).max(200) });
