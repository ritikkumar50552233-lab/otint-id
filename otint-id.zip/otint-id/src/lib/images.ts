export const MIN_IMAGES = 5;
export const MAX_IMAGES = 8;
export const MAX_IMAGE_BYTES = 1_000_000; // per image, after client-side optimisation
export const MAX_TOTAL_BYTES = 4_300_000; // stays under the ~4.5MB serverless request limit
export const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"] as const;
export type AllowedType = (typeof ALLOWED_TYPES)[number];

/** Detect the real image type from magic bytes (never trust the client's MIME type). */
export function detectImageType(b: Uint8Array): AllowedType | null {
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (
    b.length >= 8 &&
    b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 &&
    b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a
  )
    return "image/png";
  if (
    b.length >= 12 &&
    b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
    b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50
  )
    return "image/webp";
  return null;
}

export const EXTENSION: Record<AllowedType, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

export type ValidImage = { buffer: Buffer; type: AllowedType };
export type ImageCheck = { ok: true; images: ValidImage[] } | { ok: false; error: string };

export async function validateImageFiles(files: File[]): Promise<ImageCheck> {
  if (files.length < MIN_IMAGES) return { ok: false, error: `Upload at least ${MIN_IMAGES} photos.` };
  if (files.length > MAX_IMAGES) return { ok: false, error: `Upload at most ${MAX_IMAGES} photos.` };
  let total = 0;
  const images: ValidImage[] = [];
  for (const f of files) {
    if (f.size === 0) return { ok: false, error: "One of the photos is empty." };
    if (f.size > MAX_IMAGE_BYTES) return { ok: false, error: `"${f.name}" is too large after optimisation.` };
    total += f.size;
    const buffer = Buffer.from(await f.arrayBuffer());
    const type = detectImageType(buffer);
    if (!type) return { ok: false, error: `"${f.name}" is not a valid JPEG, PNG or WEBP image.` };
    images.push({ buffer, type });
  }
  if (total > MAX_TOTAL_BYTES) return { ok: false, error: "Photos are too large in total. Try smaller photos." };
  return { ok: true, images };
}
