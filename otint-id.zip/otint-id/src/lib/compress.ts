import { ALLOWED_TYPES, MAX_IMAGE_BYTES } from "./images";

const MAX_INPUT_BYTES = 25 * 1024 * 1024;
const MAX_DIMENSION = 1280;

function toBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", quality));
}

/** Validates a picked photo and re-encodes it as a resized JPEG so uploads stay small and fast. */
export async function prepareImage(file: File): Promise<File> {
  if (!(ALLOWED_TYPES as readonly string[]).includes(file.type)) {
    throw new Error(`"${file.name}" is not allowed. Use JPEG, PNG or WEBP.`);
  }
  if (file.size > MAX_INPUT_BYTES) throw new Error(`"${file.name}" is too large (max 25MB).`);

  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error(`"${file.name}" could not be read as an image.`);
  }
  const scale = Math.min(1, MAX_DIMENSION / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Your browser could not process the image.");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();

  let blob = await toBlob(canvas, 0.78);
  if (blob && blob.size > MAX_IMAGE_BYTES) blob = await toBlob(canvas, 0.55);
  if (!blob || blob.size > MAX_IMAGE_BYTES) throw new Error(`"${file.name}" is too large even after optimising.`);
  return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" });
}
