import { randomUUID } from "node:crypto";
import type { Prisma } from "@prisma/client";
import { prisma } from "./db";
import { PUBLIC_SELECT, toPublicListing, type PublicListing } from "./serializers";
import type { ListingFields } from "./validation";
import { normalizePhone } from "./validation";

export type Filters = {
  minLevel?: number;
  minPrice?: number;
  maxPrice?: number;
  age?: string;
  discount?: boolean;
  sort: "newest" | "price_asc" | "price_desc";
};

type Params = Record<string, string | string[] | undefined>;

const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

function num(v: string | string[] | undefined): number | undefined {
  const s = first(v)?.trim();
  if (!s) return undefined;
  const n = Number(s);
  return Number.isFinite(n) && n >= 0 && n <= 1_000_000_000 ? Math.floor(n) : undefined;
}

export function parseFilters(sp: Params): Filters {
  const sort = first(sp.sort);
  const age = first(sp.age)?.trim().slice(0, 50);
  return {
    minLevel: num(sp.minLevel),
    minPrice: num(sp.minPrice),
    maxPrice: num(sp.maxPrice),
    age: age || undefined,
    discount: first(sp.discount) === "1",
    sort: sort === "price_asc" || sort === "price_desc" ? sort : "newest",
  };
}

/** Public queries ALWAYS filter on status = ACTIVE. */
export function buildPublicWhere(f: Partial<Filters>): Prisma.ListingWhereInput {
  const where: Prisma.ListingWhereInput = { status: "ACTIVE" };
  if (f.minLevel != null) where.level = { gte: f.minLevel };
  if (f.minPrice != null || f.maxPrice != null) {
    where.price = {
      ...(f.minPrice != null ? { gte: f.minPrice } : {}),
      ...(f.maxPrice != null ? { lte: f.maxPrice } : {}),
    };
  }
  if (f.age) where.accountAge = { contains: f.age, mode: "insensitive" };
  if (f.discount) where.discount = { not: null };
  return where;
}

export function buildOrderBy(sort: Filters["sort"]): Prisma.ListingOrderByWithRelationInput[] {
  if (sort === "price_asc") return [{ price: "asc" }, { createdAt: "desc" }];
  if (sort === "price_desc") return [{ price: "desc" }, { createdAt: "desc" }];
  return [{ createdAt: "desc" }];
}

export async function listPublicListings(f: Partial<Filters> = {}, take = 60): Promise<PublicListing[]> {
  const rows = await prisma.listing.findMany({
    where: buildPublicWhere(f),
    orderBy: buildOrderBy(f.sort ?? "newest"),
    select: PUBLIC_SELECT,
    take,
  });
  return rows.map(toPublicListing);
}

export async function getPublicListing(listingId: string): Promise<PublicListing | null> {
  const row = await prisma.listing.findFirst({
    where: { listingId, status: "ACTIVE" },
    select: PUBLIC_SELECT,
  });
  return row ? toPublicListing(row) : null;
}

/** Creates an ACTIVE listing immediately (no approval step). Listing ID is derived from a DB sequence, so it cannot collide. */
export async function createListing(fields: ListingFields, images: string[]): Promise<string> {
  const result = await prisma.$transaction(async (tx) => {
    const created = await tx.listing.create({
      data: {
        listingId: `TMP-${randomUUID()}`,
        sellerPhone: fields.sellerPhone,
        uid: fields.uid,
        price: fields.price,
        discount: fields.discount ?? null,
        level: fields.level ?? null,
        accountAge: fields.accountAge ?? null,
        description: fields.description,
        images,
        status: "ACTIVE",
      },
      select: { id: true, seq: true },
    });
    return tx.listing.update({
      where: { id: created.id },
      data: { listingId: `OT-${1000 + created.seq}` },
      select: { listingId: true },
    });
  });
  return result.listingId;
}

export function buildAdminWhere(q: string | undefined, status: string | undefined): Prisma.ListingWhereInput {
  const where: Prisma.ListingWhereInput = {};
  if (status === "ACTIVE" || status === "SOLD" || status === "DELETED") where.status = status;
  const term = q?.trim().slice(0, 50);
  if (term) {
    const phone = normalizePhone(term);
    where.OR = [
      { listingId: { contains: term, mode: "insensitive" } },
      { uid: { contains: term } },
      { sellerPhone: { contains: phone || term } },
    ];
  }
  return where;
}
