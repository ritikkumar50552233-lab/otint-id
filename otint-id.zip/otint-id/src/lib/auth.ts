import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { SESSION_COOKIE, readCookie, verifySessionToken } from "./session";

function resolveHash(): string | null {
  const raw = process.env.ADMIN_PASSWORD_HASH?.trim();
  if (!raw) return null;
  if (raw.startsWith("$2")) return raw;
  try {
    const decoded = Buffer.from(raw, "base64").toString("utf8");
    return decoded.startsWith("$2") ? decoded : null;
  } catch {
    return null;
  }
}

export async function verifyPassword(password: string): Promise<boolean> {
  const hash = resolveHash();
  if (!hash) return false;
  return bcrypt.compare(password, hash);
}

/** For API route handlers: returns a 401 response if not authenticated, otherwise null. */
export async function requireAdminApi(req: Request): Promise<NextResponse | null> {
  const token = readCookie(req.headers.get("cookie"), SESSION_COOKIE);
  if (await verifySessionToken(token)) return null;
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}

/** For server components: redirects to the login page if not authenticated. */
export async function requireAdminPage(): Promise<void> {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (!(await verifySessionToken(token))) redirect("/admin/login");
}
