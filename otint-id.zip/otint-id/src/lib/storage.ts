import { put, del } from "@vercel/blob";
import { randomUUID } from "node:crypto";
import { EXTENSION, type ValidImage } from "./images";

/** Uploads validated images to Vercel Blob and returns their public URLs. */
export async function uploadImages(images: ValidImage[]): Promise<string[]> {
  if (!process.env.BLOB_READ_WRITE_TOKEN) throw new Error("Image storage is not configured");
  const folder = randomUUID();
  const urls: string[] = [];
  try {
    for (let i = 0; i < images.length; i++) {
      const img = images[i];
      const blob = await put(`listings/${folder}/${i + 1}-${randomUUID()}.${EXTENSION[img.type]}`, img.buffer, {
        access: "public",
        contentType: img.type,
        addRandomSuffix: false,
      });
      urls.push(blob.url);
    }
  } catch (err) {
    await deleteImages(urls);
    throw err;
  }
  return urls;
}

export async function deleteImages(urls: string[]): Promise<void> {
  if (urls.length === 0) return;
  try {
    await del(urls);
  } catch {
    /* best effort cleanup */
  }
}
