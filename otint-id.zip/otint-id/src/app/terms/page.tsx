import type { Metadata } from "next";

export const metadata: Metadata = { title: "Terms & Disclaimer" };

export default function Terms() {
  return (
    <article className="mx-auto max-w-2xl space-y-4 text-sm leading-relaxed">
      <h1 className="text-3xl font-extrabold">Terms &amp; Disclaimer</h1>
      <p><strong>OTINT ID is an independent platform.</strong></p>
      <p>OTINT ID is not affiliated with, owned by, sponsored by, or officially associated with Garena or Free Fire.</p>
      <p>Users are responsible for following applicable laws and the current terms/rules of the relevant game publisher. Account trading may be restricted or prohibited by a game publisher; OTINT ID does not claim that it is officially permitted.</p>
      <p>OTINT ID does not guarantee account ownership, recovery, continued access, suspension status, transaction safety, or successful transactions. Listings are submitted by third-party sellers and are published immediately without review. Verify everything yourself before any transaction.</p>
      <p>Sellers&apos; contact details are kept private. Buyers enquire through OTINT ID Management on WhatsApp.</p>
    </article>
  );
}
