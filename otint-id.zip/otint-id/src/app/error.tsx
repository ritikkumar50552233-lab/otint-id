"use client";

export default function ErrorPage({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="card mx-auto max-w-md p-8 text-center" role="alert">
      <h1 className="text-xl font-extrabold">Something went wrong</h1>
      <p className="mt-2 text-sm text-muted">We couldn&apos;t load this page. Please try again.</p>
      <button onClick={reset} className="btn-primary mt-5">Try again</button>
    </div>
  );
}
