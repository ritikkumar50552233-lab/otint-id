import Link from "next/link";

export default function NotFound() {
  return (
    <div className="card mx-auto max-w-md p-8 text-center">
      <h1 className="text-3xl font-extrabold">404</h1>
      <p className="mt-2 text-muted">This page or listing doesn&apos;t exist, or it is no longer available.</p>
      <Link href="/buy" className="btn-primary mt-5">Browse IDs</Link>
    </div>
  );
}
