import type { Metadata } from "next";
import Link from "next/link";
import ListingCard from "@/components/ListingCard";
import EmptyState from "@/components/EmptyState";
import { listPublicListings, parseFilters } from "@/lib/listings";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "ID Collection" };

export default async function BuyPage({ searchParams }: { searchParams: Record<string, string | string[] | undefined> }) {
  const f = parseFilters(searchParams);
  let listings: Awaited<ReturnType<typeof listPublicListings>> = [];
  let failed = false;
  try {
    listings = await listPublicListings(f);
  } catch {
    failed = true;
  }
  const hasFilters = f.minLevel != null || f.minPrice != null || f.maxPrice != null || f.age || f.discount || f.sort !== "newest";

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-extrabold">ID COLLECTION</h1>

      <form method="get" className="card grid grid-cols-2 gap-3 p-4 md:grid-cols-4 lg:grid-cols-7" aria-label="Filters">
        <div><label className="label" htmlFor="minLevel">Min level</label>
          <input id="minLevel" name="minLevel" type="number" min={0} inputMode="numeric" defaultValue={f.minLevel ?? ""} className="input" /></div>
        <div><label className="label" htmlFor="age">Account age</label>
          <input id="age" name="age" type="text" maxLength={50} placeholder="e.g. 3 years" defaultValue={f.age ?? ""} className="input" /></div>
        <div><label className="label" htmlFor="minPrice">Min price</label>
          <input id="minPrice" name="minPrice" type="number" min={0} inputMode="numeric" defaultValue={f.minPrice ?? ""} className="input" /></div>
        <div><label className="label" htmlFor="maxPrice">Max price</label>
          <input id="maxPrice" name="maxPrice" type="number" min={0} inputMode="numeric" defaultValue={f.maxPrice ?? ""} className="input" /></div>
        <div><label className="label" htmlFor="sort">Sort</label>
          <select id="sort" name="sort" defaultValue={f.sort} className="input">
            <option value="newest">Newest</option>
            <option value="price_asc">Price: low to high</option>
            <option value="price_desc">Price: high to low</option>
          </select></div>
        <label className="flex items-center gap-2 self-end py-3 text-sm font-semibold">
          <input type="checkbox" name="discount" value="1" defaultChecked={f.discount} className="h-5 w-5 accent-[#7c5cff]" />
          Has discount
        </label>
        <div className="col-span-2 flex items-end gap-2 md:col-span-1">
          <button type="submit" className="btn-primary flex-1">Apply</button>
          {hasFilters && <Link href="/buy" className="btn-ghost">Clear</Link>}
        </div>
      </form>

      {failed ? (
        <EmptyState title="Couldn't load listings" text="Please refresh the page in a moment." />
      ) : listings.length === 0 ? (
        <EmptyState
          title={hasFilters ? "No IDs match your filters" : "No IDs listed yet"}
          text={hasFilters ? "Try widening your filters." : "Listings appear here the moment they are submitted."}
          cta={hasFilters ? { href: "/buy", label: "Clear filters" } : { href: "/sell", label: "List your ID" }}
        />
      ) : (
        <>
          <p className="text-sm text-muted">{listings.length} ID{listings.length === 1 ? "" : "s"} available</p>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {listings.map((l) => <ListingCard key={l.listingId} l={l} />)}
          </div>
        </>
      )}
    </div>
  );
}
