import Link from "next/link";
import ListingCard from "@/components/ListingCard";
import EmptyState from "@/components/EmptyState";
import { listPublicListings } from "@/lib/listings";

export const dynamic = "force-dynamic";

export default async function Home() {
  let listings: Awaited<ReturnType<typeof listPublicListings>> = [];
  let failed = false;
  try {
    listings = await listPublicListings({ sort: "newest" }, 12);
  } catch {
    failed = true;
  }

  return (
    <div className="space-y-10">
      <section className="rounded-2xl border border-line bg-panel px-5 py-10 text-center sm:py-14">
        <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl">OTINT <span className="text-brand2">ID</span></h1>
        <p className="mx-auto mt-3 max-w-md text-balance text-muted">
          Buy &amp; Sell Gaming IDs with a Simple and Secure Inquiry Process
        </p>
        <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
          <Link href="/sell" className="btn-primary">SELL ID</Link>
          <Link href="/buy" className="btn-ghost">BUY ID</Link>
        </div>
      </section>

      <section aria-labelledby="latest">
        <div className="mb-4 flex items-center justify-between">
          <h2 id="latest" className="text-xl font-extrabold">Latest / Recent IDs</h2>
          <Link href="/buy" className="text-sm font-semibold text-brand2 hover:underline">See all</Link>
        </div>
        {failed ? (
          <EmptyState title="Couldn't load listings" text="Please refresh the page in a moment." />
        ) : listings.length === 0 ? (
          <EmptyState title="No IDs listed yet" text="Be the first to list an ID. It goes live instantly." cta={{ href: "/sell", label: "List your ID" }} />
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {listings.map((l) => <ListingCard key={l.listingId} l={l} />)}
          </div>
        )}
      </section>
    </div>
  );
}
