import type { Metadata, Viewport } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "OTINT ID — Gaming ID Marketplace", template: "%s | OTINT ID" },
  description: "Buy & Sell Gaming IDs with a Simple and Secure Inquiry Process. OTINT ID is an independent platform.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0b0d17" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">
        <header className="sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <Link href="/" className="text-xl font-extrabold tracking-tight">
              OTINT <span className="text-brand2">ID</span>
            </Link>
            <nav className="flex items-center gap-2 text-sm font-semibold">
              <Link href="/buy" className="rounded-lg px-3 py-2 hover:bg-panel">Buy</Link>
              <Link href="/sell" className="btn-primary btn-sm">Sell ID</Link>
            </nav>
          </div>
        </header>
        <main className="mx-auto min-h-[70vh] max-w-6xl px-4 py-6">{children}</main>
        <footer className="mt-10 border-t border-line px-4 py-6 text-center text-xs text-muted">
          <p>OTINT ID is an independent platform, not affiliated with, owned by, sponsored by, or officially associated with Garena or Free Fire.</p>
          <p className="mt-2"><Link href="/terms" className="underline">Terms &amp; Disclaimer</Link></p>
        </footer>
      </body>
    </html>
  );
}
