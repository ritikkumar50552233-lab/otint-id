import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Gallery from "@/components/Gallery";
import { getPublicListing } from "@/lib/listings";
import { getBaseUrl } from "@/lib/site";
import { buildWhatsAppUrl, formatPrice } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

type Props = { params: { listingId: string }; searchParams: Record<string, string | string[] | undefined> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  return { title: `Listing ${params.listingId}` };
}

export default async function ListingPage({ params, searchParams }: Props) {
  const l = await getPublicListing(params.listingId).catch(() => null);
  if (!l) notFound();

  const wa = buildWhatsAppUrl(process.env.MANAGEMENT_WHATSAPP_NUMBER, {
    listingId: l.listingId,
    uid: l.uid,
    price: l.price,
    url: `${getBaseUrl()}/id/${l.listingId}`,
  });

  return (
    <div className="space-y-5">
      {searchParams.new === "1" && (
        <div role="status" className="rounded-xl border border-ok/40 bg-ok/10 p-4 text-sm">
          <p className="font-bold text-ok">Your ID is live!</p>
          <p className="mt-1">Listing <strong>{l.listingId}</strong> is now active and visible to buyers. Buyers will contact OTINT ID Management, who will reach out to you.</p>
        </div>
      )}
      <div className="grid gap-6 lg:grid-cols-2">
        <Gallery images={l.images} label={l.listingId} />
        <div className="space-y-4">
          <div>
            <p className="text-sm font-semibold text-brand2">Listing ID {l.listingId}</p>
            <h1 className="mt-1 text-3xl font-extrabold text-gold">{formatPrice(l.price)}</h1>
            {l.discount && <p className="mt-1 inline-block rounded-md bg-gold px-2 py-1 text-xs font-bold text-bg">{l.discount}</p>}
          </div>
          <dl className="card divide-y divide-line text-sm">
            <Row k="UID" v={l.uid} />
            {l.level != null && <Row k="Account level" v={String(l.level)} />}
            {l.accountAge && <Row k="Account age" v={l.accountAge} />}
            <Row k="Listed" v={new Date(l.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })} />
          </dl>
          <div>
            <h2 className="mb-1 font-bold">About this ID</h2>
            <p className="whitespace-pre-line break-words text-sm text-muted">{l.description}</p>
          </div>
          {wa ? (
            <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-ok w-full">INQUIRE ON WHATSAPP</a>
          ) : (
            <p className="card p-3 text-sm text-muted" role="alert">WhatsApp inquiries are temporarily unavailable.</p>
          )}
          <p className="text-xs text-muted">You will chat with OTINT ID Management, not the seller directly. OTINT ID does not guarantee any transaction. See <Link href="/terms" className="underline">Terms</Link>.</p>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-4 px-4 py-3">
      <dt className="text-muted">{k}</dt>
      <dd className="break-all text-right font-semibold">{v}</dd>
    </div>
  );
}
