import { NextResponse } from "next/server";
import { getPublicListing } from "@/lib/listings";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: { listingId: string } }) {
  try {
    const listing = await getPublicListing(params.listingId);
    if (!listing) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ listing });
  } catch {
    return NextResponse.json({ error: "Could not load listing" }, { status: 500 });
  }
}
