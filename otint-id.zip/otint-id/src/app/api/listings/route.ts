import { NextResponse, type NextRequest } from "next/server";
import { listingFieldsSchema, fieldErrors } from "@/lib/validation";
import { validateImageFiles } from "@/lib/images";
import { uploadImages, deleteImages } from "@/lib/storage";
import { createListing, listPublicListings, parseFilters } from "@/lib/listings";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const sp = Object.fromEntries(req.nextUrl.searchParams.entries());
    const listings = await listPublicListings(parseFilters(sp));
    return NextResponse.json({ listings });
  } catch {
    return NextResponse.json({ error: "Could not load listings" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  if (!rateLimit(`create:${clientIp(req)}`, 5, 10 * 60_000)) {
    return NextResponse.json({ error: "Too many submissions. Please try again in a few minutes." }, { status: 429 });
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Invalid form submission." }, { status: 400 });
  }

  const raw: Record<string, string> = {};
  for (const [k, v] of form.entries()) if (typeof v === "string") raw[k] = v;

  const parsed = listingFieldsSchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json({ error: "Please fix the highlighted fields.", fields: fieldErrors(parsed.error) }, { status: 422 });
  }

  const files = form.getAll("images").filter((f): f is File => typeof f !== "string");
  const check = await validateImageFiles(files);
  if (!check.ok) return NextResponse.json({ error: check.error, fields: { images: check.error } }, { status: 422 });

  let urls: string[] = [];
  try {
    urls = await uploadImages(check.images);
    const listingId = await createListing(parsed.data, urls);
    return NextResponse.json({ listingId, url: `/id/${listingId}` }, { status: 201 });
  } catch (err) {
    await deleteImages(urls);
    console.error("create listing failed", err instanceof Error ? err.message : "unknown");
    return NextResponse.json({ error: "Could not save your listing. Please try again." }, { status: 500 });
  }
}
