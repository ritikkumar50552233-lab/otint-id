import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { requireAdminApi } from "@/lib/auth";
import { buildAdminWhere } from "@/lib/listings";
import { toAdminListing } from "@/lib/serializers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const denied = await requireAdminApi(req);
  if (denied) return denied;
  const q = req.nextUrl.searchParams.get("q") ?? undefined;
  const status = req.nextUrl.searchParams.get("status") ?? undefined;
  const rows = await prisma.listing.findMany({
    where: buildAdminWhere(q, status),
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json({ listings: rows.map(toAdminListing) });
}
