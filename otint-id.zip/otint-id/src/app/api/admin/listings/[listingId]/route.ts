import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { requireAdminApi } from "@/lib/auth";
import { toAdminListing } from "@/lib/serializers";
import { adminActionSchema, fieldErrors } from "@/lib/validation";

export const runtime = "nodejs";

type Ctx = { params: { listingId: string } };

export async function PATCH(req: Request, { params }: Ctx) {
  const denied = await requireAdminApi(req);
  if (denied) return denied;

  const body = adminActionSchema.safeParse(await req.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: "Invalid request", fields: fieldErrors(body.error) }, { status: 422 });

  const where = { listingId: params.listingId };
  const existing = await prisma.listing.findUnique({ where, select: { id: true } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const a = body.data;
  const data: Prisma.ListingUpdateInput =
    a.action === "sold"
      ? { status: "SOLD" as const }
      : a.action === "restore"
        ? { status: "ACTIVE" as const }
        : {
            sellerPhone: a.fields.sellerPhone,
            uid: a.fields.uid,
            price: a.fields.price,
            discount: a.fields.discount ?? null,
            level: a.fields.level ?? null,
            accountAge: a.fields.accountAge ?? null,
            description: a.fields.description,
          };

  const updated = await prisma.listing.update({ where, data });
  return NextResponse.json({ listing: toAdminListing(updated) });
}

/** "Delete" is a soft delete (status = DELETED); it can be undone with Restore. */
export async function DELETE(req: Request, { params }: Ctx) {
  const denied = await requireAdminApi(req);
  if (denied) return denied;
  const where = { listingId: params.listingId };
  const existing = await prisma.listing.findUnique({ where, select: { id: true } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const updated = await prisma.listing.update({ where, data: { status: "DELETED" } });
  return NextResponse.json({ listing: toAdminListing(updated) });
}
