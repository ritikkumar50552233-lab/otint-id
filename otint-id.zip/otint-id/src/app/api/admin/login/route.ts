import { NextResponse } from "next/server";
import { verifyPassword } from "@/lib/auth";
import { SESSION_COOKIE, SESSION_MAX_AGE, createSessionToken } from "@/lib/session";
import { clientIp, rateLimit } from "@/lib/ratelimit";
import { loginSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(req: Request) {
  if (!rateLimit(`login:${clientIp(req)}`, 5, 15 * 60_000)) {
    return NextResponse.json({ error: "Too many attempts. Try again later." }, { status: 429 });
  }
  const body = loginSchema.safeParse(await req.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });

  let ok = false;
  try {
    ok = await verifyPassword(body.data.password);
  } catch {
    ok = false;
  }
  if (!ok) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });

  let token: string;
  try {
    token = await createSessionToken();
  } catch {
    return NextResponse.json({ error: "Server is not configured for admin login" }, { status: 500 });
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });
  return res;
}
