import type { Metadata } from "next";
import SellForm from "@/components/SellForm";

export const metadata: Metadata = { title: "Sell your ID" };

export default function SellPage() {
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-3xl font-extrabold">Sell your ID</h1>
      <p className="text-sm text-muted">Fill in the details and add at least 5 photos. Your listing appears in Buy and Latest IDs right away.</p>
      <SellForm />
    </div>
  );
}
