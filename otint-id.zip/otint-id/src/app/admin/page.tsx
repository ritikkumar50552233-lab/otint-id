import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireAdminPage } from "@/lib/auth";
import { buildAdminWhere } from "@/lib/listings";
import { toAdminListing } from "@/lib/serializers";
import AdminListings from "./AdminListings";
import LogoutButton from "./LogoutButton";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false } };

const STATUSES = ["", "ACTIVE", "SOLD", "DELETED"];

export default async function AdminPage({ searchParams }: { searchParams: Record<string, string | string[] | undefined> }) {
  await requireAdminPage();
  const q = typeof searchParams.q === "string" ? searchParams.q : "";
  const status = typeof searchParams.status === "string" ? searchParams.status : "";
  const rows = await prisma.listing.findMany({
    where: buildAdminWhere(q, status),
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  const listings = rows.map(toAdminListing);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold">Admin dashboard</h1>
        <LogoutButton />
      </div>
      <form method="get" className="card flex flex-col gap-3 p-4 sm:flex-row" role="search">
        <div className="flex-1">
          <label htmlFor="q" className="label">Search Listing ID / UID / Phone Number</label>
          <input id="q" name="q" defaultValue={q} placeholder="OT-1001, UID or phone" className="input" />
        </div>
        <div>
          <label htmlFor="status" className="label">Status</label>
          <select id="status" name="status" defaultValue={status} className="input">
            {STATUSES.map((s) => <option key={s} value={s}>{s || "All"}</option>)}
          </select>
        </div>
        <div className="flex items-end gap-2">
          <button type="submit" className="btn-primary">Search</button>
          {(q || status) && <Link href="/admin" className="btn-ghost">Clear</Link>}
        </div>
      </form>
      <p className="text-sm text-muted">{listings.length} listing{listings.length === 1 ? "" : "s"}</p>
      <AdminListings listings={listings} />
    </div>
  );
}
