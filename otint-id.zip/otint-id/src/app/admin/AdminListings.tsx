"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { AdminListing } from "@/lib/serializers";
import { formatPrice } from "@/lib/whatsapp";
import EmptyState from "@/components/EmptyState";

const STATUS_STYLE: Record<string, string> = {
  ACTIVE: "bg-ok/15 text-ok",
  SOLD: "bg-gold/15 text-gold",
  DELETED: "bg-bad/15 text-bad",
};

export default function AdminListings({ listings }: { listings: AdminListing[] }) {
  if (listings.length === 0) return <EmptyState title="No listings found" text="Try a different search or status filter." />;
  return (
    <div className="space-y-4">
      {listings.map((l) => <Row key={l.listingId} l={l} />)}
    </div>
  );
}

function Row({ l }: { l: AdminListing }) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [fieldErr, setFieldErr] = useState<Record<string, string>>({});

  async function call(method: "PATCH" | "DELETE", body?: unknown): Promise<boolean> {
    setBusy(true);
    setMsg("");
    setFieldErr({});
    try {
      const res = await fetch(`/api/admin/listings/${encodeURIComponent(l.listingId)}`, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      if (res.status === 401) { router.replace("/admin/login"); return false; }
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        setMsg(d.error ?? "Action failed");
        setFieldErr(d.fields ?? {});
        return false;
      }
      router.refresh();
      return true;
    } catch {
      setMsg("Network error");
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function saveEdit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const fields: Record<string, string> = {};
    fd.forEach((v, k) => { if (typeof v === "string") fields[k] = v; });
    if (await call("PATCH", { action: "edit", fields })) setEditing(false);
  }

  return (
    <article className="card overflow-hidden">
      <div className="flex gap-1 overflow-x-auto bg-bg p-2">
        {l.images.map((src) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img key={src} src={src} alt="" loading="lazy" className="h-20 w-20 shrink-0 rounded object-cover" />
        ))}
      </div>
      <div className="space-y-3 p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <Link href={`/id/${l.listingId}`} target="_blank" rel="noopener noreferrer" className="text-lg font-extrabold hover:underline">{l.listingId}</Link>
          <span className={`rounded-md px-2 py-1 text-xs font-bold ${STATUS_STYLE[l.status]}`}>{l.status}</span>
        </div>
        <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm sm:grid-cols-3">
          <Item k="Seller phone" v={l.sellerPhone} strong />
          <Item k="UID" v={l.uid} />
          <Item k="Price" v={formatPrice(l.price)} />
          <Item k="Discount" v={l.discount ?? "—"} />
          <Item k="Level" v={l.level != null ? String(l.level) : "—"} />
          <Item k="Account age" v={l.accountAge ?? "—"} />
          <Item k="Created" v={new Date(l.createdAt).toLocaleString("en-IN")} />
        </dl>
        <p className="whitespace-pre-line break-words text-sm text-muted">{l.description}</p>

        {editing ? (
          <form onSubmit={saveEdit} className="space-y-3 rounded-lg border border-line p-3">
            <F id={l.listingId} n="sellerPhone" label="Phone" def={l.sellerPhone} err={fieldErr} />
            <F id={l.listingId} n="uid" label="UID" def={l.uid} err={fieldErr} />
            <F id={l.listingId} n="price" label="Price" def={String(l.price)} err={fieldErr} />
            <F id={l.listingId} n="discount" label="Discount" def={l.discount ?? ""} err={fieldErr} />
            <F id={l.listingId} n="level" label="Level" def={l.level != null ? String(l.level) : ""} err={fieldErr} />
            <F id={l.listingId} n="accountAge" label="Account age" def={l.accountAge ?? ""} err={fieldErr} />
            <div>
              <label className="label" htmlFor={`d-${l.listingId}`}>Description</label>
              <textarea id={`d-${l.listingId}`} name="description" rows={4} defaultValue={l.description} className="input" />
              {fieldErr.description && <p className="err">{fieldErr.description}</p>}
            </div>
            <div className="flex gap-2">
              <button type="submit" disabled={busy} className="btn-primary btn-sm">Save</button>
              <button type="button" onClick={() => { setEditing(false); setFieldErr({}); setMsg(""); }} className="btn-ghost btn-sm">Cancel</button>
            </div>
          </form>
        ) : (
          <div className="flex flex-wrap gap-2">
            <button disabled={busy} onClick={() => setEditing(true)} className="btn-ghost btn-sm">Edit</button>
            {l.status === "ACTIVE" && <button disabled={busy} onClick={() => call("PATCH", { action: "sold" })} className="btn-ghost btn-sm">Mark SOLD</button>}
            {l.status !== "ACTIVE" && <button disabled={busy} onClick={() => call("PATCH", { action: "restore" })} className="btn-ok btn-sm">Restore ACTIVE</button>}
            {l.status !== "DELETED" && (
              <button disabled={busy} onClick={() => { if (confirm(`Delete ${l.listingId}? You can restore it later.`)) void call("DELETE"); }} className="btn-danger btn-sm">Delete</button>
            )}
          </div>
        )}
        {msg && <p className="err" role="alert">{msg}</p>}
      </div>
    </article>
  );
}

function Item({ k, v, strong }: { k: string; v: string; strong?: boolean }) {
  return (
    <div>
      <dt className="text-xs text-muted">{k}</dt>
      <dd className={`break-all ${strong ? "font-bold text-gold" : "font-semibold"}`}>{v}</dd>
    </div>
  );
}

function F({ id, n, label, def, err }: { id: string; n: string; label: string; def: string; err: Record<string, string> }) {
  return (
    <div>
      <label className="label" htmlFor={`${n}-${id}`}>{label}</label>
      <input id={`${n}-${id}`} name={n} defaultValue={def} className="input" />
      {err[n] && <p className="err">{err[n]}</p>}
    </div>
  );
}
