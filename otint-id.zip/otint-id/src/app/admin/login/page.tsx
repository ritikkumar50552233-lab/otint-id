import type { Metadata } from "next";
import LoginForm from "./LoginForm";

export const metadata: Metadata = { title: "Admin login", robots: { index: false, follow: false } };

export default function AdminLogin() {
  return (
    <div className="card mx-auto mt-8 max-w-sm p-6">
      <h1 className="mb-4 text-xl font-extrabold">Admin login</h1>
      <LoginForm />
    </div>
  );
}
