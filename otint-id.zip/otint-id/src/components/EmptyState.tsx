import Link from "next/link";

export default function EmptyState({ title, text, cta }: { title: string; text: string; cta?: { href: string; label: string } }) {
  return (
    <div className="card p-8 text-center">
      <h2 className="text-lg font-bold">{title}</h2>
      <p className="mx-auto mt-1 max-w-sm text-sm text-muted">{text}</p>
      {cta && <Link href={cta.href} className="btn-primary mt-4">{cta.label}</Link>}
    </div>
  );
}
