"use client";
import { useState } from "react";

export default function Gallery({ images, label }: { images: string[]; label: string }) {
  const [i, setI] = useState(0);
  return (
    <div>
      <div className="aspect-[4/3] overflow-hidden rounded-xl border border-line bg-bg">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={images[i]} alt={`${label} photo ${i + 1} of ${images.length}`} className="h-full w-full object-contain" />
      </div>
      <div className="mt-3 grid grid-cols-5 gap-2 sm:grid-cols-6">
        {images.map((src, idx) => (
          <button
            key={src}
            type="button"
            onClick={() => setI(idx)}
            aria-label={`Show photo ${idx + 1}`}
            aria-current={idx === i}
            className={`aspect-square overflow-hidden rounded-lg border-2 ${idx === i ? "border-brand2" : "border-line"}`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={src} alt="" loading="lazy" className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
