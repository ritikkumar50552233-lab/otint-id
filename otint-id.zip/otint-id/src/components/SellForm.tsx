"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { fieldErrors, listingFieldsSchema } from "@/lib/validation";
import { MAX_IMAGES, MIN_IMAGES, MAX_TOTAL_BYTES } from "@/lib/images";
import { prepareImage } from "@/lib/compress";

type Item = { key: string; file: File; preview: string };
type Errors = Record<string, string>;

let counter = 0;
const nextKey = () => `img-${++counter}`;

export default function SellForm() {
  const router = useRouter();
  const addRef = useRef<HTMLInputElement>(null);
  const replaceRef = useRef<HTMLInputElement>(null);
  const replaceKey = useRef<string | null>(null);
  const itemsRef = useRef<Item[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);
  const [processing, setProcessing] = useState(false);

  itemsRef.current = items;
  useEffect(() => () => itemsRef.current.forEach((i) => URL.revokeObjectURL(i.preview)), []);

  async function toItems(files: File[]): Promise<Item[]> {
    const out: Item[] = [];
    for (const f of files) {
      const file = await prepareImage(f);
      out.push({ key: nextKey(), file, preview: URL.createObjectURL(file) });
    }
    return out;
  }

  async function onAdd(e: React.ChangeEvent<HTMLInputElement>) {
    const picked: File[] = e.target.files ? Array.from(e.target.files) : [];
    e.target.value = "";
    if (picked.length === 0) return;
    const room = MAX_IMAGES - items.length;
    if (picked.length > room) {
      setErrors((p) => ({ ...p, images: `You can upload at most ${MAX_IMAGES} photos.` }));
      picked.length = Math.max(0, room);
    } else setErrors((p) => ({ ...p, images: "" }));
    setProcessing(true);
    try {
      const added = await toItems(picked);
      setItems((p) => [...p, ...added]);
    } catch (err) {
      setErrors((p) => ({ ...p, images: err instanceof Error ? err.message : "Could not add photo." }));
    } finally {
      setProcessing(false);
    }
  }

  async function onReplace(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    const key = replaceKey.current;
    e.target.value = "";
    if (!f || !key) return;
    setProcessing(true);
    try {
      const [fresh] = await toItems([f]);
      setItems((p) =>
        p.map((i) => {
          if (i.key !== key) return i;
          URL.revokeObjectURL(i.preview);
          return fresh;
        })
      );
      setErrors((p) => ({ ...p, images: "" }));
    } catch (err) {
      setErrors((p) => ({ ...p, images: err instanceof Error ? err.message : "Could not replace photo." }));
    } finally {
      setProcessing(false);
    }
  }

  function remove(key: string) {
    setItems((p) => {
      const gone = p.find((i) => i.key === key);
      if (gone) URL.revokeObjectURL(gone.preview);
      return p.filter((i) => i.key !== key);
    });
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy || processing) return;
    const fd = new FormData(e.currentTarget);
    const raw: Record<string, string> = {};
    fd.forEach((v, k) => { if (typeof v === "string") raw[k] = v; });

    const errs: Errors = {};
    const parsed = listingFieldsSchema.safeParse(raw);
    if (!parsed.success) Object.assign(errs, fieldErrors(parsed.error));
    if (items.length < MIN_IMAGES) errs.images = `Add at least ${MIN_IMAGES} photos (you have ${items.length}).`;
    else if (items.reduce((s, i) => s + i.file.size, 0) > MAX_TOTAL_BYTES) errs.images = "Photos are too large in total. Remove one or use smaller photos.";
    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      requestAnimationFrame(() => document.querySelector<HTMLElement>("[data-invalid='true']")?.focus());
      return;
    }

    const body = new FormData();
    for (const [k, v] of Object.entries(raw)) body.append(k, v);
    items.forEach((i) => body.append("images", i.file));

    setBusy(true);
    try {
      const res = await fetch("/api/listings", { method: "POST", body });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setErrors({ ...(data.fields ?? {}), form: data.error ?? "Something went wrong. Please try again." });
        return;
      }
      router.push(`${data.url}?new=1`);
    } catch {
      setErrors({ form: "Network error. Check your connection and try again." });
    } finally {
      setBusy(false);
    }
  }

  const field = (name: string) => ({
    id: name,
    name,
    "aria-invalid": errors[name] ? true : undefined,
    "aria-describedby": errors[name] ? `${name}-err` : undefined,
    "data-invalid": errors[name] ? "true" : undefined,
  });
  const Err = ({ n }: { n: string }) => (errors[n] ? <p id={`${n}-err`} className="err" role="alert">{errors[n]}</p> : null);

  return (
    <form onSubmit={onSubmit} noValidate className="card space-y-5 p-4 sm:p-6">
      <div>
        <span className="label" id="photos-label">ID Photos <span className="text-muted">(minimum {MIN_IMAGES}, max {MAX_IMAGES})</span></span>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4" aria-labelledby="photos-label">
          {items.map((i, idx) => (
            <div key={i.key} className="relative overflow-hidden rounded-lg border border-line">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={i.preview} alt={`Selected photo ${idx + 1}`} className="aspect-square w-full object-cover" />
              <div className="absolute inset-x-0 bottom-0 flex gap-1 bg-bg/85 p-1">
                <button type="button" className="flex-1 rounded bg-panel px-1 py-1.5 text-[11px] font-semibold" onClick={() => { replaceKey.current = i.key; replaceRef.current?.click(); }}>Replace</button>
                <button type="button" className="flex-1 rounded bg-panel px-1 py-1.5 text-[11px] font-semibold text-bad" onClick={() => remove(i.key)} aria-label={`Remove photo ${idx + 1}`}>Remove</button>
              </div>
            </div>
          ))}
          {items.length < MAX_IMAGES && (
            <button type="button" onClick={() => addRef.current?.click()} disabled={processing}
              className="flex aspect-square flex-col items-center justify-center rounded-lg border-2 border-dashed border-line text-xs font-semibold text-muted hover:border-brand2" >
              <span className="text-2xl leading-none">+</span>{processing ? "Processing…" : "Add photos"}
            </button>
          )}
        </div>
        <input ref={addRef} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={onAdd} />
        <input ref={replaceRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={onReplace} />
        <p className="hint">{items.length} of {MIN_IMAGES} required photos. JPEG, PNG or WEBP.</p>
        <Err n="images" />
      </div>

      <div>
        <label className="label" htmlFor="sellerPhone">Your WhatsApp / Phone Number</label>
        <input {...field("sellerPhone")} type="tel" inputMode="tel" autoComplete="tel" placeholder="+91 98765 43210" className="input" />
        <p className="hint">Private. Never shown to buyers.</p>
        <Err n="sellerPhone" />
      </div>
      <div>
        <label className="label" htmlFor="uid">UID Number</label>
        <input {...field("uid")} type="text" inputMode="numeric" placeholder="e.g. 123456789" className="input" />
        <Err n="uid" />
      </div>
      <div>
        <label className="label" htmlFor="price">Selling Price (₹)</label>
        <input {...field("price")} type="number" inputMode="numeric" min={1} className="input" />
        <Err n="price" />
      </div>
      <div className="grid gap-5 sm:grid-cols-3">
        <div>
          <label className="label" htmlFor="discount">Discount / Special Offer <span className="text-muted">(optional)</span></label>
          <input {...field("discount")} type="text" maxLength={100} placeholder="e.g. 10% off" className="input" />
          <Err n="discount" />
        </div>
        <div>
          <label className="label" htmlFor="level">Account Level <span className="text-muted">(optional)</span></label>
          <input {...field("level")} type="number" inputMode="numeric" min={1} className="input" />
          <Err n="level" />
        </div>
        <div>
          <label className="label" htmlFor="accountAge">Account Age <span className="text-muted">(optional)</span></label>
          <input {...field("accountAge")} type="text" maxLength={50} placeholder="e.g. 3 years" className="input" />
          <Err n="accountAge" />
        </div>
      </div>
      <div>
        <label className="label" htmlFor="description">Tell buyers about this ID</label>
        <textarea {...field("description")} rows={5} maxLength={1000} className="input" />
        <Err n="description" />
      </div>

      {errors.form && <p className="rounded-lg border border-bad/40 bg-bad/10 p-3 text-sm text-bad" role="alert">{errors.form}</p>}
      <button type="submit" disabled={busy || processing} className="btn-primary w-full">
        {busy ? "Listing your ID…" : "APPLY / LIST ID"}
      </button>
      <p className="text-center text-xs text-muted">Your listing goes live immediately. No approval step.</p>
    </form>
  );
}
