import Link from "next/link";
import type { PublicListing } from "@/lib/serializers";
import { formatPrice } from "@/lib/whatsapp";

export default function ListingCard({ l }: { l: PublicListing }) {
  return (
    <article className="card rise overflow-hidden">
      <Link href={`/id/${l.listingId}`} className="block" aria-label={`View ${l.listingId}`}>
        <div className="relative aspect-[4/3] bg-bg">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={l.images[0]} alt={`Screenshot of ${l.listingId}`} loading="lazy" className="h-full w-full object-cover" />
          <span className="absolute left-2 top-2 rounded-md bg-bg/90 px-2 py-1 text-xs font-bold">{l.listingId}</span>
          {l.discount && (
            <span className="absolute right-2 top-2 rounded-md bg-gold px-2 py-1 text-xs font-bold text-bg">{l.discount}</span>
          )}
        </div>
      </Link>
      <div className="space-y-2 p-4">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm text-muted">UID <span className="font-semibold text-ink">{l.uid}</span></p>
          <p className="text-lg font-extrabold text-gold">{formatPrice(l.price)}</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {l.level != null && <span className="chip">Level {l.level}</span>}
          {l.accountAge && <span className="chip">Age {l.accountAge}</span>}
        </div>
        <p className="line-clamp-2 text-sm text-muted">{l.description}</p>
        <Link href={`/id/${l.listingId}`} className="btn-ghost btn-sm w-full">View Details</Link>
      </div>
    </article>
  );
}
