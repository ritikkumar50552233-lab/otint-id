# OTINT ID

OTINT ID is an independent gaming-account marketplace. It is **not** affiliated with, owned by, sponsored by, or officially associated with Garena or Free Fire.

**Core flow:** `SELL → APPLY → server validation → image upload → PostgreSQL → status ACTIVE → instantly visible in /buy and Latest IDs → listing page`. There is **no approval step** and no pending status.

## Tech stack
Next.js 14 (App Router) · TypeScript · Tailwind CSS · PostgreSQL + Prisma · Zod · Vercel Blob (image storage) · bcryptjs + jose (admin auth) · Vitest.

## Folder structure
```
prisma/                 schema + migrations
scripts/hash-password.mjs
src/app/                pages (/, /sell, /buy, /id/[listingId], /terms, /admin, /admin/login) and API routes
src/app/api/listings    public create/list/detail
src/app/api/admin       login, logout, search, edit, sold, restore, delete (all auth-checked)
src/components/         UI components
src/lib/                validation, images, storage, serializers (public/private DTOs), whatsapp, auth, session, ratelimit, listings
src/middleware.ts       blocks unauthenticated /admin and /api/admin (handlers re-check too)
tests/                  Vitest tests
```

## Environment variables
Copy `.env.example` to `.env` (local) and fill in. Never commit `.env`.

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `MANAGEMENT_WHATSAPP_NUMBER` | Management number: digits only, country code first |
| `ADMIN_PASSWORD_HASH` | bcrypt hash of the admin password (see below) |
| `SESSION_SECRET` | random string, 32+ chars (`openssl rand -base64 48`) |
| `BLOB_READ_WRITE_TOKEN` | Vercel Blob read/write token |
| `NEXT_PUBLIC_SITE_URL` | optional; public URL used in WhatsApp messages (defaults to request host) |

### Admin password
```
npm run hash-password -- "your-strong-password"
```
It prints a raw bcrypt hash and a base64 version. In a local `.env` use the **base64** value (bcrypt hashes contain `$`, which dotenv expands). On Vercel either works. The admin login is at `/admin/login` (not linked anywhere).

## Local setup
1. `npm install`
2. Create a PostgreSQL database (local, Neon, Supabase, or Vercel Postgres) and set `DATABASE_URL`.
3. `npm run db:migrate:dev` (local dev) — applies `prisma/migrations`.
4. Create a Vercel Blob store (Vercel dashboard → Storage → Blob) and copy its `BLOB_READ_WRITE_TOKEN` into `.env`. Uploads need this token even locally.
5. `npm run dev` → http://localhost:3000

Cloud dev (Codespaces/Gitpod etc.): same steps; use a hosted PostgreSQL URL.

## Commands
`npm run dev` · `npm run lint` · `npm run typecheck` · `npm test` · `npm run build` · `npm start` · `npm run db:migrate` (deploy migrations)

## Deploy to Vercel (you deploy it)
1. Import the repo/ZIP contents into a Vercel project.
2. Add all environment variables above (Production + Preview).
3. Add a Blob store to the project (this injects `BLOB_READ_WRITE_TOKEN`).
4. Use a hosted PostgreSQL (Vercel Postgres/Neon/Supabase). If your provider uses pooled connections, use the direct/non-pooled URL for migrations if `migrate deploy` hangs.
5. The project defines `vercel-build` = `prisma generate && prisma migrate deploy && next build`, so migrations are applied on deploy. Alternatively run `npm run db:migrate` yourself against production once.

## Security notes
- Seller phone is stored in `sellerPhone` and is **only** read by admin code paths. Public queries use an explicit `select` (`PUBLIC_SELECT`) and public output is built by `toPublicListing`, which picks fields explicitly. Tests assert this.
- Public queries always filter `status = ACTIVE`. SOLD/DELETED disappear from Buy, Latest and detail pages; Restore brings them back.
- Admin: bcrypt password hash, signed HS256 JWT in an HTTP-only, SameSite=Strict, Secure (prod) cookie; middleware + per-handler checks.
- Uploads: client resizes/re-encodes to JPEG; server re-validates count (5–8), size, and real file type via magic bytes (JPEG/PNG/WEBP). Serverless request bodies are limited to ~4.5MB, hence the client-side optimisation and total-size cap.
- Zod validation on client and server; angle brackets/control characters stripped from text.
- Rate limiting (listing creation, admin login) is in-memory and per-instance: best-effort only. For stronger protection use a shared store (e.g. Upstash Redis).
- Listings publish instantly with no review, so spam is possible; consider moderation tooling and CAPTCHA if abused.
- "Delete" in admin is a soft delete (status `DELETED`); images remain in Blob storage.

## Tests
`npm test` runs Vitest (`tests/`): validation, image checks, WhatsApp link, privacy/serializers, admin session + password, middleware, API flow (mocked DB), and `acceptance.test.ts` (SELL → APPLY → ACTIVE → BUY/Latest → DETAIL → WHATSAPP → ADMIN search/SOLD/DELETE/restore/edit). The database and Vercel Blob are replaced by in-memory stand-ins in these tests, so they do **not** exercise real PostgreSQL or real image storage. Run a manual smoke test against a real database after deploying.
