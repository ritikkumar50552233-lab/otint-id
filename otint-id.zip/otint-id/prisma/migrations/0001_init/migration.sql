-- CreateEnum
CREATE TYPE "ListingStatus" AS ENUM ('ACTIVE', 'SOLD', 'DELETED');

-- CreateTable
CREATE TABLE "Listing" (
    "id" TEXT NOT NULL,
    "seq" SERIAL NOT NULL,
    "listingId" TEXT NOT NULL,
    "sellerPhone" TEXT NOT NULL,
    "uid" TEXT NOT NULL,
    "price" INTEGER NOT NULL,
    "discount" TEXT,
    "level" INTEGER,
    "accountAge" TEXT,
    "description" TEXT NOT NULL,
    "images" TEXT[],
    "status" "ListingStatus" NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Listing_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Listing_seq_key" ON "Listing"("seq");
CREATE UNIQUE INDEX "Listing_listingId_key" ON "Listing"("listingId");
CREATE INDEX "Listing_status_createdAt_idx" ON "Listing"("status", "createdAt");
CREATE INDEX "Listing_uid_idx" ON "Listing"("uid");
CREATE INDEX "Listing_sellerPhone_idx" ON "Listing"("sellerPhone");
